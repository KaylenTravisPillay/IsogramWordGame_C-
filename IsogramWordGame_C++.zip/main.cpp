#include <iostream>
#include <string>
#include "FBullCowGame.h"

//Allow syntax to lean towards the Unreal engines standards
using FText = std::string;
using int32 = int;


void PrintIntro();
void PrintGameSummary();
void PlayGame();
FText GetDifficulty();
FText GetValidGuess();
bool AskToPlayAgain();

FBullCowGame BCGame;

//The entry point of the game.
int main() 
{
	
	do
	{
		PrintIntro();
		PlayGame();

	} while (AskToPlayAgain());
	

	std::cout << std::endl;
	return 0;
}

//Introduce the game to the player
void PrintIntro()
{
	std::cout << std::endl;
	std::cout << "\n\nWelcome to Bulls and Cows, a fun word game.\n";
	std::cout << std::endl;
	std::cout << "          }   {         ___ " << std::endl;
	std::cout << "          (o o)        (o o) " << std::endl;
	std::cout << "   /-------\\ /          \\ /-------\\ " << std::endl;
	std::cout << "  / | BULL |O            O| COW  | \\ " << std::endl;
	std::cout << " *  |-,--- |              |------|  * " << std::endl;
	std::cout << "    ^      ^              ^      ^ " << std::endl;
	
	std::cout << "Can you guess the " << BCGame.GetHiddenWordLength();
	std::cout << " letter isogram I'm thinking of?\n";
	std::cout << "'An Isogram is a word with no repeating letters'\n";
	std::cout << std::endl;

	return;
}



//Play the game.
void PlayGame()
{
	BCGame.SetDifficulty(GetDifficulty());
	BCGame.Reset();

	int32 MaxTries = BCGame.GetMaxTries();

	// Loop for the number of turns asking for guesses.
	while(!BCGame.IsGameWon() && BCGame.GetCurrentTry() <= MaxTries)
	{
		FText PlayerGuess = GetValidGuess();// Get a valid guess from the player

		// submit guess to the game
		FBullCowCount BullCowCount =  BCGame.SubmitValidGuess(PlayerGuess);
		// print number of bulls and cows
		
		std::cout << "Bulls = " << BullCowCount.Bulls;
		std::cout << ". Cows = " << BullCowCount.Cows << std::endl;

		std::cout << std::endl;
	}

	PrintGameSummary();
	return;
}

FText GetDifficulty()
{
	FString PlayerDifficultyChoice;
	std::cout << "Please choose a difficulty (Easy/Normal/Hard):\n";
	std::getline(std::cin, PlayerDifficultyChoice);
	return PlayerDifficultyChoice;
}

//Get the guess from the player
FText GetValidGuess() 
{
	FText Guess = "";
	EGuessStatus Status = EGuessStatus::Invalid_Status;
	do
	{
		int32 CurrentTry = BCGame.GetCurrentTry();
		std::cout << "Try " << CurrentTry << " of " << BCGame.GetMaxTries() << ": ";
		std::cout << "What is your guess? ";

		getline(std::cin, Guess);

		Status = BCGame.CheckGuessValidity(Guess);
		switch (Status)
		{
		case EGuessStatus::Wrong_length:
			std::cout << "Please enter a " << BCGame.GetHiddenWordLength() << " letter word as your guess.\n\n";
			break;
		case EGuessStatus::Not_lowercase:
			std::cout << "Please enter use only lowercase characters in your guess.\n\n";
			break;
		case EGuessStatus::Not_Isogram:
			std::cout << "Please make sure that your guess is an Isogram.\n\n";
			break;
		default:
			;
		}
	} while (Status != EGuessStatus::OK);
	return Guess;
}

void PrintGameSummary()
{
	if (BCGame.IsGameWon())
	{
		std::cout << "WELL DONE YOU GUESSED RIGHT, YOU WIN! :)\n";
	}
	else
	{
		std::cout << "YOU RAN OUT OF TRIES, BETTER LUCK NEXT TIME :(\n";
	}
}

//Ask the player whether they want to play again.
bool AskToPlayAgain()
{
	std::cout << "Do you want to play again with the same hidden word? Yes/No";
	std::cout << std::endl;
	FText Response = "";
	getline(std::cin, Response);

	return (Response[0] == 'Y' || Response[0] == 'y');
}