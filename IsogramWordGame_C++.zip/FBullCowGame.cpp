#pragma once
#include "FBullCowGame.h"
#include <map>
#define TMap std::map

using FString = std::string;
using int32 = int;

FBullCowGame::FBullCowGame()
{
	Reset();
}

int32 FBullCowGame::GetMaxTries() const{ return MyMaxTries; }

int32 FBullCowGame::GetCurrentTry() const{ return MyCurrentTries; }

int32 FBullCowGame::GetHiddenWordLength() const { return MyHiddenWord.length(); };

bool FBullCowGame::IsGameWon() const{ return bCorrectGuess;}


void FBullCowGame::Reset()
{
	
	constexpr int32 CURRENTTRIES = 1;

	MyCurrentTries = CURRENTTRIES;
	bCorrectGuess = false;
	return;
}


EGuessStatus FBullCowGame::CheckGuessValidity(FString Guess) const
{
	if (!IsIsogram(Guess))//if the guess is not an isogram
	{
		return EGuessStatus::Not_Isogram;
	}
	else if (!IsLowercase(Guess))//if the guess isnt all lower case
	{
		return EGuessStatus::Not_lowercase;
	}
	else if(GetHiddenWordLength() != Guess.length())//if the guess length is wrong
	{

		return EGuessStatus::Wrong_length;

	}
	else
	{
		return EGuessStatus::OK;
	}
	
}

// receives a valid guess ancd increments try number
FBullCowCount FBullCowGame::SubmitValidGuess(FString Guess)
{
	MyCurrentTries ++;
	FBullCowCount BullCowCount;
	int32 WordLength = MyHiddenWord.length(); // assuming the guess is the same length as the hidden word.

	// loop through all the letters in the hiddenword
	for (int32 MHWChar = 0; MHWChar < WordLength; MHWChar++)
	{
		//compare each letter in the guess.
		for (int32 GChar = 0; GChar < WordLength; GChar++)
		{
			//if the letters match
			if (Guess[GChar] == MyHiddenWord[MHWChar])
			{
				//if the letter is in the write position
				if (MHWChar == GChar)
				{
					BullCowCount.Bulls++;
				}
				//else
				else
				{
					BullCowCount.Cows++;
				}
			}
			
		}
	}
	if (BullCowCount.Bulls == GetHiddenWordLength())
	{
		bCorrectGuess = true;
	}
	return BullCowCount;
}

void FBullCowGame::SetDifficulty(FString Difficulty)
{
	if (Difficulty == "Easy")
	{
		constexpr int32 MAXTRIES = 4;
		const FString HIDDENWORD = "gem";

		MyMaxTries = MAXTRIES;
		MyHiddenWord = HIDDENWORD;

	}
	else if (Difficulty == "Normal")
	{
		constexpr int32 MAXTRIES = 10;
		const FString HIDDENWORD = "path";

		MyMaxTries = MAXTRIES;
		MyHiddenWord = HIDDENWORD;
	}
	else if (Difficulty == "Hard")
	{
		constexpr int32 MAXTRIES = 18;
		const FString HIDDENWORD = "cabin";

		MyMaxTries = MAXTRIES;
		MyHiddenWord = HIDDENWORD;
	}
	else
	{
		constexpr int32 MAXTRIES = 4;
		const FString HIDDENWORD = "gem";

		MyMaxTries = MAXTRIES;
		MyHiddenWord = HIDDENWORD;
	}
}

bool FBullCowGame::IsIsogram(FString Word) const
{
	//treat 0 or 1 letter words as an Isogram
	if (Word.length() <= 1) { return true; }

	TMap<char, bool> LetterSeen;

	//loop through all the letters in the word
	for (auto Letter : Word)
	{
		Letter = tolower(Letter);
		if (LetterSeen[Letter]) { 
			return false; // We don't have an Isogram.
		}else
			{
				LetterSeen[Letter] = true;
			}
			
	}
	return true;
}

bool FBullCowGame::IsLowercase(FString Word) const
{
	if (Word.length() <= 1) { return true; }

	for (auto Letter:Word)
	{
		if (!islower(Letter))
		{
			return false;
		}
	}
	return true;
}
